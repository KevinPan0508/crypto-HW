Problem 4 ：直接執行 code4.py
Problem 5 ：直接執行 code5.py, 使用到 gmpy2, python版本為 3.6
Problem 7 ：直接執行 code7.py, iv 的部分為事先做好記錄下來，若要測試可以取消 87行的註解
Problem 8 ：直接執行 code8.py